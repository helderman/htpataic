extern void host(bool (*action)(char *, int));

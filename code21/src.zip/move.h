extern int moveObject(OBJECT *obj, OBJECT *to);

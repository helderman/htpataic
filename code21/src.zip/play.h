extern int executePlay(void);

extern void printSetCurrent(int fd);
extern void printPrivate(const char *format, ...);
extern void printSee(const char *format, ...);
extern void printHear(const char *format, ...);

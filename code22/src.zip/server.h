extern void server(void (*action)(char *, int));

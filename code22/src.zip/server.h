extern void server(bool (*action)(char *, int));

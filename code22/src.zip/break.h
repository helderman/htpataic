extern void breakInit(void);
extern bool breakTest(void);
extern int breakSignalNumber(void);

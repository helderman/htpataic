extern void breakInit(void);
extern bool breakTest(void);

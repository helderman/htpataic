extern int executePlay(void);
extern int executeEmote(void);
extern int executeSay(void);
extern int executeWhisper(void);

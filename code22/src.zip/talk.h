extern int executeTalk(void);
extern int executeTalkTo(void);

extern OBJECT *actorHere(void);
extern int listObjectsAtLocation(OBJECT *location);

extern bool parseAndExecute(char *input);

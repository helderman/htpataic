extern bool executeLookAround(void);
extern bool executeLook(void);
extern bool executeGo(void);

extern bool executeTurnOn(void);
extern bool executeTurnOff(void);

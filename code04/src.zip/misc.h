extern int listObjectsAtLocation(OBJECT *location);

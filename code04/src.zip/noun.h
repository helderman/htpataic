extern OBJECT *getVisible(const char *intention, const char *noun);

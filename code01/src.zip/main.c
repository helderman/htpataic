#include <stdio.h>

int main()
{
   printf("Welcome to Little Cave Adventure.\n");
   printf("It is very dark in here.\n");
   printf("\nBye!\n");
   return 0;
}

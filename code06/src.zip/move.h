extern void moveObject(OBJECT *obj, OBJECT *to);

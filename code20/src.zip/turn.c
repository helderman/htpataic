#include <stdbool.h>
#include <stdio.h>

bool turn(int time)
{
   if (time <= 0) return time == 0;
   // TODO
   printf("You hear a bird singing in the distance.\n");
   return true;
}

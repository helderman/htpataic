extern int executeLookAround(void);
extern int executeLook(void);
extern int executeGo(void);

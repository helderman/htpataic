extern char *expand(char *input, int bufsize);

extern bool executeOpen(void);
extern bool executeClose(void);
extern bool executeLock(void);
extern bool executeUnlock(void);

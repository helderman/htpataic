extern bool parseAndExecute(const char *input);

extern bool executeTalk(void);
extern bool executeTalkTo(void);

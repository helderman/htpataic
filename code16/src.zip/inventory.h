extern bool executeGet(void);
extern bool executeDrop(void);
extern bool executeAsk(void);
extern bool executeGive(void);
extern bool executeInventory(void);
